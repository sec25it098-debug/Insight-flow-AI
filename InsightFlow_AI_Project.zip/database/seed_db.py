import sqlite3
from pathlib import Path

DB = Path(__file__).resolve().parent / "ecommerce.db"
con = sqlite3.connect(DB)
cur = con.cursor()

cur.executescript("""
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS customers;

CREATE TABLE customers(
    customer_id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    city TEXT
);

CREATE TABLE products(
    product_id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    category TEXT NOT NULL,
    price REAL NOT NULL
);

CREATE TABLE orders(
    order_id INTEGER PRIMARY KEY,
    customer_id INTEGER,
    product_id INTEGER,
    quantity INTEGER,
    unit_price REAL,
    order_date TEXT,
    FOREIGN KEY(customer_id) REFERENCES customers(customer_id),
    FOREIGN KEY(product_id) REFERENCES products(product_id)
);
""")

cur.executemany("INSERT INTO customers VALUES (?, ?, ?)", [
    (1,"Ananya","Chennai"),(2,"Rahul","Bengaluru"),(3,"Meera","Coimbatore"),
    (4,"Arjun","Hyderabad"),(5,"Diya","Madurai")
])
cur.executemany("INSERT INTO products VALUES (?, ?, ?, ?)", [
    (1,"Laptop Pro","Electronics",85000),(2,"Smartphone X","Electronics",55000),
    (3,"Tablet Z","Electronics",32000),(4,"Office Chair","Furniture",12000),
    (5,"Desk Lamp","Furniture",2500),(6,"Smart Watch","Wearables",9000)
])
cur.executemany("INSERT INTO orders VALUES (?, ?, ?, ?, ?, ?)", [
    (1,1,1,2,85000,"2026-01-05"),(2,2,2,3,55000,"2026-01-12"),
    (3,3,3,4,32000,"2026-01-18"),(4,4,4,5,12000,"2026-02-03"),
    (5,5,5,8,2500,"2026-02-10"),(6,1,6,6,9000,"2026-02-18"),
    (7,2,1,1,85000,"2026-03-05"),(8,3,2,2,55000,"2026-03-15"),
    (9,4,3,3,32000,"2026-03-22"),(10,5,4,2,12000,"2026-04-02"),
    (11,1,5,10,2500,"2026-04-11"),(12,2,6,5,9000,"2026-04-20")
])
con.commit()
con.close()
print(f"Created {DB}")
