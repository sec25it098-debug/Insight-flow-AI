from tools.query import execute_query

def test_select_query():
    df = execute_query("SELECT COUNT(*) AS n FROM orders")
    assert int(df.iloc[0]["n"]) > 0

def test_reject_non_select():
    try:
        execute_query("DELETE FROM orders")
        assert False
    except ValueError:
        assert True
