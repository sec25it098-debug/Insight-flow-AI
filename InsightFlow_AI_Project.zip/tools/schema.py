from tools.query import DB_PATH
import sqlite3

def get_schema():
    con = sqlite3.connect(DB_PATH)
    tables = con.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
    ).fetchall()
    result = {}
    for (table,) in tables:
        cols = con.execute(f"PRAGMA table_info({table})").fetchall()
        result[table] = [
            {"name": c[1], "type": c[2], "primary_key": bool(c[5])} for c in cols
        ]
    con.close()
    return result
