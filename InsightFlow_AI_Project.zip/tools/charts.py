import plotly.express as px

def generate_chart(df, chart_type):
    if df.empty:
        return None

    x, y = df.columns[0], df.columns[1]

    if chart_type == "line":
        return px.line(df, x=x, y=y, markers=True, title="Trend")
    if chart_type == "pie":
        return px.pie(df, names=x, values=y, title="Distribution")
    if chart_type == "scatter":
        return px.scatter(df, x=x, y=y, title="Relationship")
    return px.bar(df, x=x, y=y, title="Comparison")
