import sqlite3
from pathlib import Path
import pandas as pd

DB_PATH = Path(__file__).resolve().parent.parent / "database" / "ecommerce.db"

def execute_query(sql):
    # Demo safety: only allow read-only SELECT statements.
    normalized = sql.strip().lower()
    if not normalized.startswith("select"):
        raise ValueError("Only SELECT queries are allowed.")
    con = sqlite3.connect(DB_PATH)
    try:
        return pd.read_sql_query(sql, con)
    finally:
        con.close()
