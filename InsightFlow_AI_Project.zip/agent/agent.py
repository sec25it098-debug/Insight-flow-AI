import re
from tools.schema import get_schema
from tools.query import execute_query
from tools.charts import generate_chart
from tools.explain import explain_data

def _choose_sql(question):
    q = question.lower()

    if "top 5" in q and "product" in q and ("revenue" in q or "sales" in q):
        return """SELECT p.name AS product, SUM(o.quantity * o.unit_price) AS revenue
FROM orders o JOIN products p ON p.product_id = o.product_id
GROUP BY p.product_id, p.name
ORDER BY revenue DESC LIMIT 5;"""

    if "revenue by category" in q or ("category" in q and "revenue" in q):
        return """SELECT p.category, SUM(o.quantity * o.unit_price) AS revenue
FROM orders o JOIN products p ON p.product_id = o.product_id
GROUP BY p.category ORDER BY revenue DESC;"""

    if "monthly" in q and "revenue" in q:
        return """SELECT strftime('%Y-%m', order_date) AS month,
SUM(quantity * unit_price) AS revenue
FROM orders GROUP BY month ORDER BY month;"""

    if "customer" in q and "order" in q:
        return """SELECT c.name AS customer, COUNT(o.order_id) AS orders
FROM customers c JOIN orders o ON c.customer_id = o.customer_id
GROUP BY c.customer_id, c.name ORDER BY orders DESC;"""

    # Safe fallback for demo
    return """SELECT p.category, SUM(o.quantity * o.unit_price) AS revenue
FROM orders o JOIN products p ON p.product_id = o.product_id
GROUP BY p.category ORDER BY revenue DESC;"""

def analyze_question(question):
    sql = _choose_sql(question)
    data = execute_query(sql)
    q = question.lower()

    if "monthly" in q or "trend" in q:
        chart_type = "line"
    elif "category" in q:
        chart_type = "pie"
    elif "top" in q or "customer" in q:
        chart_type = "bar"
    else:
        chart_type = "bar"

    figure = generate_chart(data, chart_type)
    answer = explain_data(question, data)

    return {"answer": answer, "sql": sql, "data": data, "figure": figure}
