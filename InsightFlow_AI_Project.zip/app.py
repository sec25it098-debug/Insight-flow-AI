import streamlit as st
from agent.agent import analyze_question
from tools.schema import get_schema

st.set_page_config(page_title="InsightFlow AI", page_icon="📊", layout="wide")

st.title("📊 InsightFlow AI")
st.caption("Your conversational data analyst — ask questions, visualize results, and discover why.")

with st.sidebar:
    st.header("Database")
    st.write("Demo: SQLite e-commerce database")
    if st.button("Show schema"):
        st.json(get_schema())
    st.divider()
    st.markdown("**Try asking:**")
    st.write("• Show top 5 products by revenue")
    st.write("• Show revenue by category")
    st.write("• Show monthly revenue trend")
    st.write("• Why did revenue change?")

if "messages" not in st.session_state:
    st.session_state.messages = []

for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])
        if msg.get("figure") is not None:
            st.plotly_chart(msg["figure"], use_container_width=True)
        if msg.get("data") is not None:
            st.dataframe(msg["data"], use_container_width=True)
        if msg.get("sql"):
            with st.expander("🔍 Show SQL"):
                st.code(msg["sql"], language="sql")

prompt = st.chat_input("Ask your database a question...")
if prompt:
    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.markdown(prompt)

    with st.chat_message("assistant"):
        with st.spinner("Analyzing your data..."):
            result = analyze_question(prompt)

        st.markdown(result["answer"])
        if result.get("figure") is not None:
            st.plotly_chart(result["figure"], use_container_width=True)
        if result.get("data") is not None:
            st.dataframe(result["data"], use_container_width=True)
        if result.get("sql"):
            with st.expander("🔍 Show SQL"):
                st.code(result["sql"], language="sql")

    st.session_state.messages.append({
        "role": "assistant",
        "content": result["answer"],
        "figure": result.get("figure"),
        "data": result.get("data"),
        "sql": result.get("sql")
    })
