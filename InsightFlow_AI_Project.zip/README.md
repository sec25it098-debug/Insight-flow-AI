# InsightFlow AI

**Conversational Data Analyst for Natural-Language Database Exploration**

InsightFlow AI is a hackathon MVP that lets users ask questions about an e-commerce SQLite database in natural language. It executes safe read-only SQL, generates interactive charts, and explains the result.

## Problem alignment

The hackathon asks for an LLM-powered conversational application that can understand natural-language data questions, query SQL/NoSQL databases, generate visualizations, and explain insights. The required tools are `get_schema`, `execute_query`, `generate_chart`, `generate_flowchart`, and `explain_data`.

This repository implements the core database, query, chart, schema, and explanation layers. The current MVP uses deterministic intent-to-SQL rules so it can run without an API key. An LLM adapter can be added later for true function calling.

## Features

- ChatGPT-style Streamlit interface
- Natural-language demo queries
- SQLite e-commerce database
- Schema discovery
- Read-only SQL execution
- Bar, line and pie charts
- SQL transparency
- Conversational data explanations
- Session chat history
- Unit tests

## Architecture

User → Streamlit Chat UI → Analyst Agent → SQL Tool → SQLite → DataFrame → Chart + Explanation

## Setup

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate

pip install -r requirements.txt
python database/seed_db.py
streamlit run app.py
```

Open the local URL shown by Streamlit.

## Demo questions

- Show the top 5 products by revenue
- Show revenue by category
- Show monthly revenue trend
- Show customers with the most orders

## Testing

```bash
pytest -q
```

## Hackathon extensions

1. Replace `_choose_sql()` with an LLM function-calling adapter.
2. Add `generate_flowchart()` using Mermaid.
3. Add root-cause analysis for “Why?” questions.
4. Add CSV/PNG export.
5. Add query history and favorites.
6. Add multi-database connectors.
7. Add a dashboard builder.

## Security notes

The query tool only accepts SELECT statements in this MVP. API keys, if later added, should be stored in environment variables or deployment secrets and never committed to GitHub.

## Documentation references

- Streamlit chat elements: https://docs.streamlit.io/develop/tutorials/chat-and-llm-apps/build-conversational-apps
- Streamlit API: https://docs.streamlit.io/develop/api-reference
- Plotly Python: https://plotly.com/python/getting-started/
