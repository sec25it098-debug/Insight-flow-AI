# InsightFlow AI — Project Documentation

## 1. Project title

InsightFlow AI — Conversational Data Analyst

## 2. Abstract

InsightFlow AI is a conversational analytics application designed to reduce the difficulty of interacting with structured databases. A user can ask a data question in natural language. The system identifies the intended analysis, retrieves data using a read-only SQL query, creates a suitable visualization, and returns a human-readable explanation.

## 3. Problem statement

Traditional database analysis often requires SQL knowledge and familiarity with database schemas. The proposed system creates a conversational layer between a non-technical user and an e-commerce database.

## 4. Objectives

- Natural-language data interaction
- Database schema discovery
- SQL query execution
- Interactive visualization
- Conversational explanation
- Transparent SQL
- Multi-turn chat foundation
- Graceful error handling

## 5. Required tools

### get_schema
Returns tables, columns, types and primary-key information.

### execute_query
Executes a read-only SELECT query and returns tabular data.

### generate_chart
Creates bar, line, pie or scatter visualizations from tabular results.

### generate_flowchart
Planned extension for ER diagrams and process flows.

### explain_data
Converts query results into a concise natural-language insight.

## 6. Data flow

1. User enters a question.
2. Agent determines the analysis intent.
3. Agent chooses/generates SQL.
4. Query tool validates the query as read-only.
5. SQLite executes the query.
6. DataFrame is returned.
7. Chart tool selects a visualization.
8. Explanation tool produces an insight.
9. Streamlit displays the answer, chart, table and SQL.

## 7. Example

Question: "Show revenue by category"

SQL:
SELECT p.category, SUM(o.quantity * o.unit_price) AS revenue
FROM orders o JOIN products p ON p.product_id = o.product_id
GROUP BY p.category ORDER BY revenue DESC;

Output:
- category/revenue table
- pie chart
- natural-language explanation
- expandable SQL

## 8. Innovation

The intended next-stage feature is "Ask WHY". Instead of stopping after returning a metric, the agent can automatically investigate related dimensions such as category, product and customer and produce a root-cause explanation.

## 9. Limitations of this MVP

The included agent uses deterministic intent-to-SQL mappings rather than a live LLM. This is intentional so the repository can run locally without an API key. For final hackathon submission, an LLM function-calling adapter should be added.

## 10. Future work

- LLM function calling
- Mermaid ER/process diagrams
- root-cause analysis
- multi-database support
- CSV/PDF/PNG export
- voice input
- query history
- custom dashboards
- deployment

## 11. Evaluation mapping

Functionality: chat, query, schema and charts.

Tool design: separate modules for schema, queries, charts and explanations.

Visualization: bar, line and pie charts.

UX: conversational interface and transparent SQL.

Innovation: planned root-cause/"Ask WHY" workflow.
