def explain_data(question, df):
    if df.empty:
        return "I couldn't find matching data for that question."

    first = df.iloc[0]
    cols = list(df.columns)
    if len(cols) >= 2:
        value = first[cols[1]]
        return (
            f"### 💡 Key Insight\n\n"
            f"Based on the database results, **{first[cols[0]]}** has the highest "
            f"value in this analysis (**{value:,.2f}** where applicable).\n\n"
            f"I generated the visualization from the query results and included "
            f"the SQL used so the calculation is transparent."
        )
    return "The query returned data successfully. Review the table for the detailed results."
